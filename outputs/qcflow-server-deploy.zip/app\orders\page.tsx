"use client";

import { StatusBadge } from "@/components/StatusBadge";
import { shortDate } from "@/lib/format";
import { supabase } from "@/lib/supabaseClient";
import type { Order } from "@/lib/types";
import { ArrowRight, FileText, Plus, ScanLine } from "lucide-react";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

function sortByShippingDate(a: Order, b: Order) {
  const aDate = a.shipping_date ?? "9999-12-31";
  const bDate = b.shipping_date ?? "9999-12-31";
  if (aDate !== bDate) return aDate.localeCompare(bDate);
  return b.created_at.localeCompare(a.created_at);
}

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data } = await supabase.from("orders").select("*").order("shipping_date", { ascending: true, nullsFirst: false });
      setOrders((data ?? []) as Order[]);
      setLoading(false);
    }

    load();
  }, []);

  const customerGroups = useMemo(() => {
    const groups = new Map<string, Order[]>();

    for (const order of orders) {
      const customerName = order.customer_name || "未分类客户";
      groups.set(customerName, [...(groups.get(customerName) ?? []), order]);
    }

    return Array.from(groups.entries())
      .map(([customerName, customerOrders]) => ({
        customerName,
        totalQuantity: customerOrders.reduce((sum, order) => sum + order.quantity, 0),
        inboundQuantity: customerOrders.reduce((sum, order) => sum + Number(order.inbound_quantity || 0), 0),
        orders: customerOrders.sort(sortByShippingDate)
      }))
      .sort((a, b) => a.customerName.localeCompare(b.customerName, "zh-Hans-CN"));
  }, [orders]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black tracking-normal text-blue-950">订单列表</h1>
          <p className="mt-1 text-sm text-blue-700">按客户名称分类，客户下面按出货日期排序。</p>
        </div>
        <Link href="/orders/new" className="primary-btn">
          <Plus size={18} />
          入库
        </Link>
      </div>

      <div className="space-y-4">
        {loading && <div className="panel p-5 text-sm text-slate-500">正在加载...</div>}
        {!loading && orders.length === 0 && <div className="panel p-5 text-sm text-slate-500">还没有入库订单。</div>}

        {customerGroups.map((group) => (
          <section key={group.customerName} className="space-y-3">
            <div className="sticky top-0 z-10 rounded border border-blue-200 bg-blue-100/95 px-3 py-2 backdrop-blur">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <h2 className="truncate text-lg font-black text-blue-950">{group.customerName}</h2>
                  <p className="text-xs font-bold text-blue-700">{group.orders.length} 个订单</p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-xs font-bold text-blue-700">预约 / 已入</p>
                  <p className="text-xl font-black text-blue-950">
                    {group.totalQuantity} / {group.inboundQuantity}
                  </p>
                </div>
              </div>
            </div>

            {group.orders.map((order) => (
              <article key={order.id} className="panel p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="truncate text-lg font-black">{order.po_number}</h3>
                      <StatusBadge status={order.status} />
                    </div>
                    <p className="mt-1 text-sm text-slate-500">入库：{shortDate(order.created_at)}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-xs font-bold text-blue-700">未入库</p>
                    <p className="text-xl font-black text-blue-950">{order.quantity - Number(order.inbound_quantity || 0)}</p>
                  </div>
                </div>

                <dl className="mt-4 grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
                  <div>
                    <dt className="font-bold text-slate-500">预约 / 已入库</dt>
                    <dd className="mt-1 truncate font-black text-blue-900">
                      {order.quantity} / {order.inbound_quantity || 0}
                    </dd>
                  </div>
                  <div>
                    <dt className="font-bold text-slate-500">工厂</dt>
                    <dd className="mt-1 truncate">{order.factory_name}</dd>
                  </div>
                  <div>
                    <dt className="font-bold text-slate-500">来货日期</dt>
                    <dd className="mt-1 truncate">{order.inbound_date ?? "-"}</dd>
                  </div>
                  <div>
                    <dt className="font-bold text-slate-500">出货日期</dt>
                    <dd className="mt-1 truncate font-black text-blue-900">{order.shipping_date ?? "-"}</dd>
                  </div>
                  <div>
                    <dt className="font-bold text-slate-500">番号</dt>
                    <dd className="mt-1 truncate">{order.sku}</dd>
                  </div>
                  <div>
                    <dt className="font-bold text-slate-500">颜色 / 尺码</dt>
                    <dd className="mt-1 truncate">
                      {order.color} / {order.size}
                    </dd>
                  </div>
                </dl>

                <div className="mt-4 grid grid-cols-3 gap-3">
                  <Link href={`/inspect/${order.id}`} className="secondary-btn">
                    <ArrowRight size={18} />
                    检品
                  </Link>
                  <Link href={`/xray/${order.id}`} className="secondary-btn">
                    <ScanLine size={18} />
                    X线
                  </Link>
                  <Link href={`/report/${order.id}`} className="secondary-btn">
                    <FileText size={18} />
                    报告
                  </Link>
                </div>
              </article>
            ))}
          </section>
        ))}
      </div>
    </div>
  );
}
