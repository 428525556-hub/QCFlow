create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  user_id uuid not null references auth.users(id) on delete cascade,
  order_type text not null default 'reservation',
  customer_name text not null,
  factory_name text not null,
  po_number text not null,
  sku text not null,
  inbound_date date,
  shipping_date date,
  color text not null,
  size text not null,
  quantity integer not null check (quantity > 0),
  inbound_quantity integer not null default 0 check (inbound_quantity >= 0),
  status text not null default '未开始'
);

alter table public.orders add column if not exists order_type text not null default 'reservation';
alter table public.orders add column if not exists inbound_quantity integer not null default 0;
alter table public.orders drop constraint if exists orders_order_type_check;
alter table public.orders add constraint orders_order_type_check check (order_type in ('reservation', 'inbound'));
alter table public.orders add column if not exists inbound_date date;
alter table public.orders add column if not exists shipping_date date;
alter table public.orders drop constraint if exists orders_status_check;
alter table public.orders add constraint orders_status_check check (status in ('未开始', '检品中', '已完成'));

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  order_id uuid not null references public.orders(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  po_number text not null default '',
  sku text not null default '',
  color text not null,
  size text not null,
  quantity integer not null check (quantity > 0)
  ,
  inbound_quantity integer not null default 0 check (inbound_quantity >= 0)
);

alter table public.order_items add column if not exists po_number text not null default '';
alter table public.order_items add column if not exists sku text not null default '';
alter table public.order_items add column if not exists inbound_quantity integer not null default 0;

create table if not exists public.order_attachments (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  order_id uuid not null references public.orders(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  file_name text not null,
  file_url text not null,
  file_path text not null,
  mime_type text,
  file_size integer
);

create table if not exists public.inspection_records (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  order_id uuid not null references public.orders(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  inspection_stage text not null default 'normal',
  defect_type text not null,
  quantity integer not null check (quantity > 0),
  remark text,
  photo_url text,
  photo_path text
);

alter table public.inspection_records drop constraint if exists inspection_records_defect_type_check;
alter table public.inspection_records add column if not exists inspection_stage text not null default 'normal';
alter table public.inspection_records drop constraint if exists inspection_records_inspection_stage_check;
alter table public.inspection_records add constraint inspection_records_inspection_stage_check check (inspection_stage in ('normal', 'xray'));

alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.order_attachments enable row level security;
alter table public.inspection_records enable row level security;

drop policy if exists "users can read own orders" on public.orders;
drop policy if exists "users can insert own orders" on public.orders;
drop policy if exists "users can update own orders" on public.orders;
drop policy if exists "users can delete own orders" on public.orders;
drop policy if exists "users can read own order items" on public.order_items;
drop policy if exists "users can insert own order items" on public.order_items;
drop policy if exists "users can update own order items" on public.order_items;
drop policy if exists "users can read own order attachments" on public.order_attachments;
drop policy if exists "users can insert own order attachments" on public.order_attachments;
drop policy if exists "users can update own order attachments" on public.order_attachments;
drop policy if exists "users can read own records" on public.inspection_records;
drop policy if exists "users can insert own records" on public.inspection_records;
drop policy if exists "users can update own records" on public.inspection_records;
drop policy if exists "users can upload inspection photos" on storage.objects;
drop policy if exists "users can view inspection photos" on storage.objects;
drop policy if exists "users can upload order attachments" on storage.objects;
drop policy if exists "users can view order attachments" on storage.objects;

create policy "users can read own orders"
on public.orders for select
using (auth.uid() = user_id);

create policy "users can insert own orders"
on public.orders for insert
with check (auth.uid() = user_id);

create policy "users can update own orders"
on public.orders for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "users can delete own orders"
on public.orders for delete
using (auth.uid() = user_id);

create policy "users can read own order items"
on public.order_items for select
using (auth.uid() = user_id);

create policy "users can insert own order items"
on public.order_items for insert
with check (auth.uid() = user_id);

create policy "users can update own order items"
on public.order_items for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "users can read own order attachments" on public.order_attachments;
create policy "users can read own order attachments"
on public.order_attachments for select
using (auth.uid() = user_id);

drop policy if exists "users can insert own order attachments" on public.order_attachments;
create policy "users can insert own order attachments"
on public.order_attachments for insert
with check (auth.uid() = user_id);

drop policy if exists "users can update own order attachments" on public.order_attachments;
create policy "users can update own order attachments"
on public.order_attachments for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "users can read own records"
on public.inspection_records for select
using (auth.uid() = user_id);

create policy "users can insert own records"
on public.inspection_records for insert
with check (auth.uid() = user_id);

create policy "users can update own records"
on public.inspection_records for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

insert into storage.buckets (id, name, public)
values ('inspection-photos', 'inspection-photos', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('order-attachments', 'order-attachments', true)
on conflict (id) do nothing;

create policy "users can upload inspection photos"
on storage.objects for insert
with check (bucket_id = 'inspection-photos' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "users can view inspection photos"
on storage.objects for select
using (bucket_id = 'inspection-photos');

create policy "users can upload order attachments"
on storage.objects for insert
with check (bucket_id = 'order-attachments' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "users can view order attachments"
on storage.objects for select
using (bucket_id = 'order-attachments');
