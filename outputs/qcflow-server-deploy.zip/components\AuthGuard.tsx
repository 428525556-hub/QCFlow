"use client";

import { supabase } from "@/lib/supabaseClient";
import type { User } from "@supabase/supabase-js";
import { usePathname, useRouter } from "next/navigation";
import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext<User | null>(null);

export function useCurrentUser() {
  return useContext(AuthContext);
}

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    supabase.auth.getUser().then(({ data }) => {
      if (!mounted) return;
      setUser(data.user);
      setLoading(false);
      if (!data.user && pathname !== "/login") router.replace("/login");
      if (data.user && pathname === "/login") router.replace("/");
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (!session?.user && pathname !== "/login") router.replace("/login");
      if (session?.user && pathname === "/login") router.replace("/");
    });

    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, [pathname, router]);

  if (loading) {
    return (
      <main className="min-h-screen bg-slate-100 px-5 py-8 text-slate-900">
        <div className="mx-auto flex min-h-[70vh] max-w-md items-center justify-center">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-slate-300 border-t-machine" />
        </div>
      </main>
    );
  }

  if (!user && pathname !== "/login") return null;

  return <AuthContext.Provider value={user}>{children}</AuthContext.Provider>;
}
