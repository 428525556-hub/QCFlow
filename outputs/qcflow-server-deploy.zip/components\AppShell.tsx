"use client";

import { supabase } from "@/lib/supabaseClient";
import { Archive, CalendarDays, ClipboardList, Home, LogOut, PackagePlus, PackageSearch } from "lucide-react";
import { clsx } from "clsx";
import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

const nav = [
  { href: "/", label: "首页", icon: Home },
  { href: "/reservations/new", label: "预约", icon: PackageSearch },
  { href: "/orders/new", label: "入库", icon: PackagePlus },
  { href: "/orders", label: "检品", icon: ClipboardList },
  { href: "/calendar", label: "日历", icon: CalendarDays },
  { href: "/orders/manage", label: "总单", icon: Archive }
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const isLogin = pathname === "/login";

  if (isLogin) return <>{children}</>;

  async function signOut() {
    await supabase.auth.signOut();
    router.replace("/login");
  }

  return (
    <div className="min-h-screen bg-blue-50 text-slate-950">
      <header className="sticky top-0 z-20 border-b border-line bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center gap-3">
            <span className="relative h-10 w-10 overflow-hidden rounded border border-line bg-white">
              <Image src="/shuoyu-logo.jpg" alt="SHUOYU" fill sizes="40px" className="object-cover" priority />
            </span>
            <div>
              <p className="text-base font-black leading-tight tracking-normal">QCFlow</p>
              <p className="text-xs text-slate-500">鞋服检品管理</p>
            </div>
          </Link>
          <button type="button" onClick={signOut} className="inline-flex h-10 w-10 items-center justify-center rounded border border-line bg-white text-slate-600 shadow-panel" aria-label="退出登录" title="退出登录">
            <LogOut size={18} />
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-24 pt-5 md:pb-10">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-white md:hidden">
        <div className="grid grid-cols-6">
          {nav.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href;
            return (
              <Link key={item.href} href={item.href} className={clsx("flex flex-col items-center gap-1 px-1 py-2.5 text-[11px] font-semibold", active ? "text-machine" : "text-slate-500")}>
                <Icon size={19} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
