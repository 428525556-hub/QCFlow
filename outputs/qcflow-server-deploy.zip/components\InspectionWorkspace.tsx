"use client";

import { useCurrentUser } from "@/components/AuthGuard";
import { StatusBadge } from "@/components/StatusBadge";
import { shortDate } from "@/lib/format";
import { supabase } from "@/lib/supabaseClient";
import type { DefectGroup, InspectionRecord, InspectionStage, Order, OrderAttachment } from "@/lib/types";
import { Camera, CheckCircle2, ExternalLink, FileSpreadsheet, FileText, Minus, Plus, Save, Upload } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";

type Props = {
  orderId: string;
  stage: InspectionStage;
  title: string;
  subtitle: string;
  groups: DefectGroup[];
};

async function compressImage(file: File) {
  if (!file.type.startsWith("image/")) return file;

  const imageUrl = URL.createObjectURL(file);

  try {
    const image = await withTimeout(
      new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = imageUrl;
      }),
      8000,
      "照片读取超时，请重新拍一张或换一张图片"
    );

    const maxSide = 800;
    const scale = Math.min(1, maxSide / Math.max(image.width, image.height));
    const width = Math.max(1, Math.round(image.width * scale));
    const height = Math.max(1, Math.round(image.height * scale));

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;

    const context = canvas.getContext("2d");
    if (!context) return file;

    context.drawImage(image, 0, 0, width, height);

    const blob = await withTimeout(
      new Promise<Blob | null>((resolve) => {
        canvas.toBlob(resolve, "image/jpeg", 0.45);
      }),
      8000,
      "照片压缩超时，请重新拍一张或换一张图片"
    );

    if (!blob) return file;

    const originalMb = file.size / 1024 / 1024;
    const compressedMb = blob.size / 1024 / 1024;
    if (compressedMb >= originalMb) return file;

    const name = file.name.replace(/\.[^.]+$/, "") || "inspection-photo";
    return new File([blob], `${name}-compressed.jpg`, { type: "image/jpeg" });
  } finally {
    URL.revokeObjectURL(imageUrl);
  }
}

function formatMb(bytes: number) {
  return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
}

function createSafeId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }

  return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function safeFileName(name: string) {
  return name.replace(/[^\w.\-\u4e00-\u9fa5]/g, "_");
}

async function withTimeout<T>(promise: PromiseLike<T>, ms: number, message: string) {
  let timeoutId: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error(message)), ms);
  });

  try {
    return await Promise.race([Promise.resolve(promise), timeout]);
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}

export function InspectionWorkspace({ orderId, stage, title, subtitle, groups }: Props) {
  const router = useRouter();
  const user = useCurrentUser();

  const [order, setOrder] = useState<Order | null>(null);
  const [records, setRecords] = useState<InspectionRecord[]>([]);
  const [attachments, setAttachments] = useState<OrderAttachment[]>([]);
  const [defectType, setDefectType] = useState(groups[0]?.items[0] ?? "其他");
  const [quantity, setQuantity] = useState(1);
  const [remark, setRemark] = useState("");
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [photoProcessing, setPhotoProcessing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [uploadStatus, setUploadStatus] = useState("");
  const [attachmentUploading, setAttachmentUploading] = useState(false);
  const [attachmentStatus, setAttachmentStatus] = useState("");

  useEffect(() => {
    async function load() {
      const [{ data: orderRow }, { data: recordRows }, { data: attachmentRows }] = await Promise.all([
        supabase.from("orders").select("*").eq("id", orderId).single(),
        supabase.from("inspection_records").select("*").eq("order_id", orderId).eq("inspection_stage", stage).order("created_at", { ascending: false }),
        supabase.from("order_attachments").select("*").eq("order_id", orderId).order("created_at", { ascending: true })
      ]);
      const typedOrder = orderRow as Order | null;
      setOrder(typedOrder);
      setRecords((recordRows ?? []) as InspectionRecord[]);
      setAttachments((attachmentRows ?? []) as OrderAttachment[]);

      if (typedOrder?.status === "未开始") {
        await supabase.from("orders").update({ status: "检品中" }).eq("id", orderId);
        setOrder({ ...typedOrder, status: "检品中" });
      }
    }

    load();
  }, [orderId, stage]);

  const defectQty = useMemo(() => records.reduce((sum, record) => sum + record.quantity, 0), [records]);

  async function pickPhoto(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0] ?? null;
    if (preview) URL.revokeObjectURL(preview);
    setPreview("");
    setPhoto(null);
    setMessage("");
    event.target.value = "";

    if (!file) {
      setUploadStatus("");
      return;
    }

    setPhotoProcessing(true);
    setUploadStatus(`正在压缩照片... 原图 ${formatMb(file.size)}`);

    try {
      const compressed = await compressImage(file);
      setPhoto(compressed);
      setPreview(URL.createObjectURL(compressed));
      setMessage(`照片已压缩：${formatMb(file.size)} → ${formatMb(compressed.size)}，现在保存会更快。`);
      setUploadStatus("");
    } catch {
      setPhoto(file);
      setPreview(URL.createObjectURL(file));
      setMessage("这张照片无法自动压缩，已保留原图。建议手机相机选择较小尺寸后再拍。");
      setUploadStatus("");
    } finally {
      setPhotoProcessing(false);
    }
  }

  async function pickInstructionFiles(event: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(event.target.files ?? []);
    event.target.value = "";

    if (!user) {
      setMessage("登录状态已失效，请重新登录后再上传。");
      return;
    }

    if (files.length === 0 || attachmentUploading) return;

    setAttachmentUploading(true);
    setAttachmentStatus(`正在上传指示书... 0/${files.length}`);
    setMessage("");

    try {
      const uploadedRows: OrderAttachment[] = [];

      for (let index = 0; index < files.length; index += 1) {
        const file = files[index];
        setAttachmentStatus(`正在上传指示书... ${index + 1}/${files.length} ${file.name}`);
        const path = `${user.id}/${orderId}/${createSafeId()}-${safeFileName(file.name)}`;

        const { error: uploadError } = await withTimeout(
          supabase.storage.from("order-attachments").upload(path, file, {
            cacheControl: "3600",
            upsert: false
          }),
          45000,
          "指示书上传超时，请检查手机网络后重试"
        );

        if (uploadError) {
          throw new Error(uploadError.message);
        }

        const { data: publicUrl } = supabase.storage.from("order-attachments").getPublicUrl(path);
        uploadedRows.push({
          id: createSafeId(),
          created_at: new Date().toISOString(),
          order_id: orderId,
          user_id: user.id,
          file_name: file.name,
          file_url: publicUrl.publicUrl,
          file_path: path,
          mime_type: file.type || null,
          file_size: file.size || null
        });
      }

      const { data, error } = await withTimeout(
        supabase
          .from("order_attachments")
          .insert(
            uploadedRows.map(({ id, created_at, ...row }) => row)
          )
          .select("*"),
        20000,
        "指示书信息保存超时，请检查手机网络后重试"
      );

      if (error) {
        throw new Error(`${error.message}。请确认 Supabase 已执行最新 schema.sql，并创建 order-attachments 存储桶。`);
      }

      setAttachments((current) => [...current, ...((data ?? uploadedRows) as OrderAttachment[])]);
      setMessage("指示书已上传");
    } catch (error) {
      const detail = error instanceof Error ? error.message : "未知错误";
      setMessage(`指示书上传失败：${detail}`);
    } finally {
      setAttachmentUploading(false);
      setAttachmentStatus("");
    }
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!user) {
      setMessage("登录状态已失效，请重新登录后再上传。");
      return;
    }
    if (saving || photoProcessing) return;

    setSaving(true);
    setMessage("");
    setUploadStatus(photo ? `正在上传照片... ${formatMb(photo.size)}` : "正在保存记录...");

    try {
      let photoUrl: string | null = null;
      let photoPath: string | null = null;

      if (photo) {
        const uploadFile = photo;
        setUploadStatus(`正在上传照片... ${formatMb(uploadFile.size)}`);
        const ext = uploadFile.name.split(".").pop() || "jpg";
        photoPath = `${user.id}/${orderId}/${createSafeId()}.${ext}`;
        const { error: uploadError } = await withTimeout(
          supabase.storage.from("inspection-photos").upload(photoPath, uploadFile, {
            cacheControl: "3600",
            upsert: false
          }),
          45000,
          "手机网络上传超时，请确认手机和电脑在同一个 Wi-Fi 后重试"
        );

        if (uploadError) {
          throw new Error(uploadError.message);
        }

        const { data } = supabase.storage.from("inspection-photos").getPublicUrl(photoPath);
        photoUrl = data.publicUrl;
      }

      setUploadStatus("正在保存记录...");

      const { data, error } = await withTimeout(
        supabase
          .from("inspection_records")
          .insert({
            order_id: orderId,
            user_id: user.id,
            inspection_stage: stage,
            defect_type: defectType,
            quantity,
            remark: remark || null,
            photo_url: photoUrl,
            photo_path: photoPath
          })
          .select("*")
          .single(),
        20000,
        "保存记录超时，请检查手机网络后重试"
      );

      if (error) {
        throw new Error(`${error.message}。请确认 Supabase 已执行最新 schema.sql。`);
      }

      setRecords((current) => [data as InspectionRecord, ...current]);
      setQuantity(1);
      setRemark("");
      setPhoto(null);
      if (preview) URL.revokeObjectURL(preview);
      setPreview("");
      setMessage("已保存");
    } catch (error) {
      const detail = error instanceof Error ? error.message : "未知错误";
      setMessage(`保存失败：${detail}`);
    } finally {
      setSaving(false);
      setUploadStatus("");
    }
  }

  async function finishOrder() {
    await supabase.from("orders").update({ status: "已完成" }).eq("id", orderId);
    router.push(`/report/${orderId}`);
  }

  if (!order) {
    return <div className="panel p-5 text-sm text-slate-500">正在加载任务...</div>;
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4 pb-28 md:pb-4">
      <section className="rounded border border-blue-900 bg-blue-950 p-4 text-white">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm font-bold text-sky-300">{title}</p>
            <div className="mt-1 flex flex-wrap items-center gap-2">
              <h1 className="truncate text-2xl font-black tracking-normal">{order.po_number}</h1>
              <StatusBadge status={order.status} />
            </div>
            <p className="mt-2 text-sm text-blue-100">
              {order.customer_name} · 番号 {order.sku} · 入库 {order.quantity} 件
            </p>
            <p className="mt-1 text-xs text-blue-200">{subtitle}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-blue-200">不良数</p>
            <p className="text-2xl font-black text-sky-300">{defectQty}</p>
          </div>
        </div>
      </section>

      <section className="panel p-4">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-black">检品指示书</h2>
            <p className="mt-1 text-sm text-slate-500">用于判断哪些项目 OK / NG。</p>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <span className="rounded bg-blue-50 px-2 py-1 text-xs font-black text-blue-700">{attachments.length} 个附件</span>
            <label className={`inline-flex min-h-10 cursor-pointer items-center gap-2 rounded border border-line bg-white px-3 py-2 text-sm font-black text-machine ${attachmentUploading ? "pointer-events-none opacity-60" : ""}`}>
              <Upload size={16} />
              上传
              <input
                type="file"
                multiple
                accept="image/*,.pdf,.xls,.xlsx"
                className="sr-only"
                onChange={pickInstructionFiles}
                disabled={attachmentUploading}
              />
            </label>
          </div>
        </div>

        {attachmentUploading && attachmentStatus && (
          <div className="mb-3 rounded border border-blue-200 bg-blue-50 px-3 py-3">
            <div className="flex items-center justify-between gap-3 text-sm font-black text-blue-800">
              <span className="min-w-0 truncate">{attachmentStatus}</span>
              <span className="h-5 w-5 shrink-0 animate-spin rounded-full border-2 border-blue-200 border-t-blue-700" />
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded bg-blue-100">
              <div className="h-full w-2/3 animate-pulse rounded bg-blue-600" />
            </div>
          </div>
        )}

        {attachments.length === 0 && <div className="rounded border border-line bg-blue-50 p-3 text-sm text-slate-500">这个订单还没有上传检品指示书。</div>}

        {attachments.length > 0 && (
          <div className="grid gap-3 md:grid-cols-2">
            {attachments.map((attachment) => {
              const isImage = attachment.mime_type?.startsWith("image/") || /\.(jpg|jpeg|png|webp|gif)$/i.test(attachment.file_name);
              return (
                <article key={attachment.id} className="overflow-hidden rounded border border-line bg-blue-50">
                  {isImage ? (
                    <a href={attachment.file_url} target="_blank" rel="noreferrer" className="block bg-white">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={attachment.file_url} alt={attachment.file_name} className="h-56 w-full object-contain" />
                    </a>
                  ) : (
                    <div className="grid h-32 place-items-center bg-white text-machine">
                      <FileSpreadsheet size={40} />
                    </div>
                  )}
                  <div className="flex items-center justify-between gap-3 p-3">
                    <p className="min-w-0 truncate text-sm font-black">{attachment.file_name}</p>
                    <a href={attachment.file_url} target="_blank" rel="noreferrer" className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded border border-line bg-white text-slate-600" aria-label="打开附件">
                      <ExternalLink size={16} />
                    </a>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      <form onSubmit={submit} className="panel space-y-4 p-4">
        <div>
          <label className="label">现场照片</label>
          <label className="mt-2 flex min-h-32 cursor-pointer flex-col items-center justify-center rounded border-2 border-dashed border-line bg-blue-50 p-3 text-center">
            {preview ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={preview} alt="检品照片预览" className="max-h-56 rounded object-contain" />
            ) : (
              <>
                <Camera size={30} className="text-blue-500" />
                <span className="mt-2 text-sm font-bold text-slate-600">拍照或选择图片</span>
              </>
            )}
            <input type="file" accept="image/*" capture="environment" className="sr-only" onChange={pickPhoto} />
          </label>
        </div>

        <div>
          <label className="label">问题类别</label>
          <div className="mt-2 space-y-3">
            {groups.map((group) => (
              <section key={group.group} className="rounded border border-line bg-blue-50 p-2">
                <p className="mb-2 text-xs font-black text-blue-700">{group.group}</p>
                <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
                  {group.items.map((item) => (
                    <button
                      key={`${group.group}-${item}`}
                      type="button"
                      onClick={() => setDefectType(item)}
                      className={`min-h-11 rounded border px-2 text-sm font-black ${
                        defectType === item ? "border-blue-500 bg-blue-600 text-white" : "border-line bg-white text-slate-600"
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </section>
            ))}
          </div>
        </div>

        <div>
          <label className="label">数量</label>
          <div className="mt-2 grid grid-cols-[52px_1fr_52px] overflow-hidden rounded border border-line bg-white">
            <button type="button" className="grid min-h-12 place-items-center border-r border-line" onClick={() => setQuantity((value) => Math.max(1, value - 1))} aria-label="减少">
              <Minus size={18} />
            </button>
            <input
              className="w-full text-center text-xl font-black outline-none"
              type="number"
              inputMode="numeric"
              min={1}
              value={quantity}
              onChange={(event) => setQuantity(Math.max(1, Number(event.target.value || 1)))}
            />
            <button type="button" className="grid min-h-12 place-items-center border-l border-line" onClick={() => setQuantity((value) => value + 1)} aria-label="增加">
              <Plus size={18} />
            </button>
          </div>
        </div>

        <div>
          <label className="label" htmlFor="remark">
            备注
          </label>
          <textarea id="remark" className="field mt-2 min-h-24 resize-none" value={remark} onChange={(event) => setRemark(event.target.value)} placeholder="位置、批次、处理意见" />
        </div>

        {message && <p className="rounded bg-blue-50 px-3 py-2 text-sm font-bold text-blue-800">{message}</p>}
        {(saving || photoProcessing) && uploadStatus && (
          <div className="rounded border border-blue-200 bg-blue-50 px-3 py-3">
            <div className="flex items-center justify-between gap-3 text-sm font-black text-blue-800">
              <span>{uploadStatus}</span>
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-blue-200 border-t-blue-700" />
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded bg-blue-100">
              <div className="h-full w-2/3 animate-pulse rounded bg-blue-600" />
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <button type="submit" disabled={saving || photoProcessing} className="primary-btn">
            <Save size={18} />
            保存记录
          </button>
          <button type="button" onClick={finishOrder} className="secondary-btn">
            <CheckCircle2 size={18} />
            完成订单
          </button>
        </div>
      </form>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-black">最近记录</h2>
          <Link href={`/report/${orderId}`} className="inline-flex items-center gap-1 text-sm font-bold text-machine">
            <FileText size={16} />
            报告
          </Link>
        </div>
        <div className="space-y-3">
          {records.length === 0 && <div className="panel p-4 text-sm text-slate-500">暂无记录。</div>}
          {records.map((record) => (
            <article key={record.id} className="panel flex gap-3 p-3">
              {record.photo_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={record.photo_url} alt={record.defect_type} className="h-20 w-20 shrink-0 rounded object-cover" />
              ) : (
                <div className="grid h-20 w-20 shrink-0 place-items-center rounded bg-blue-50 text-blue-400">
                  <Camera size={22} />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-black">{record.defect_type}</p>
                  <p className="font-black text-machine">x {record.quantity}</p>
                </div>
                <p className="mt-1 text-xs text-slate-500">{shortDate(record.created_at)}</p>
                {record.remark && <p className="mt-1 line-clamp-2 text-sm text-slate-600">{record.remark}</p>}
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
