"use client";

import { StatusBadge } from "@/components/StatusBadge";
import { percent, shortDate } from "@/lib/format";
import { supabase } from "@/lib/supabaseClient";
import { defectGroups, type InspectionRecord, type Order } from "@/lib/types";
import { Download, Printer, ShieldCheck } from "lucide-react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

const pdfLabels: Record<string, string> = {
  "危害": "Hazard",
  "帮面和附件": "Upper and accessories",
  "中底和内里": "Insole and lining",
  "大底/插跟/贴合": "Outsole and bonding",
  "包装及表示不良": "Packing and labeling",
  "检针/X光": "Needle/X-ray",
  "常用补充": "Common"
};

export default function ReportPage() {
  const params = useParams<{ id: string }>();
  const orderId = params.id;
  const [order, setOrder] = useState<Order | null>(null);
  const [records, setRecords] = useState<InspectionRecord[]>([]);

  useEffect(() => {
    async function load() {
      const [{ data: orderRow }, { data: recordRows }] = await Promise.all([
        supabase.from("orders").select("*").eq("id", orderId).single(),
        supabase.from("inspection_records").select("*").eq("order_id", orderId).order("created_at", { ascending: true })
      ]);
      setOrder(orderRow as Order | null);
      setRecords((recordRows ?? []) as InspectionRecord[]);
    }

    load();
  }, [orderId]);

  const report = useMemo(() => {
    const total = order?.quantity ?? 0;
    const defectQty = records.reduce((sum, record) => sum + record.quantity, 0);
    const grouped = defectGroups.map((group) => {
      const items = group.items.map((type) => ({
        type,
        quantity: records.filter((record) => record.defect_type === type).reduce((sum, record) => sum + record.quantity, 0)
      }));
      return {
        group: group.group,
        quantity: items.reduce((sum, item) => sum + item.quantity, 0),
        items
      };
    });
    return { total, defectQty, grouped, rate: percent(defectQty, total) };
  }, [order, records]);

  async function downloadPdf() {
    if (!order) return;
    const { jsPDF } = await import("jspdf");
    const pdf = new jsPDF("landscape");

    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(16);
    pdf.text("Final Inspection / Needle Report", 14, 16);

    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    const rows = [
      `PO: ${order.po_number}`,
      `Customer: ${order.customer_name}`,
      `Factory: ${order.factory_name}`,
      `Style No: ${order.sku}`,
      `Inbound Date: ${order.inbound_date ?? ""}`,
      `Shipping Date: ${order.shipping_date ?? ""}`,
      `Inbound Qty: ${report.total}`,
      `Defect Qty: ${report.defectQty}`,
      `Defect Rate: ${report.rate}`
    ];
    rows.forEach((line, index) => pdf.text(line, 14, 28 + index * 6));

    pdf.setFont("helvetica", "bold");
    pdf.text("Defect Group Summary", 105, 28);
    pdf.setFont("helvetica", "normal");
    report.grouped.forEach((group, index) => {
      pdf.text(`${pdfLabels[group.group] ?? group.group}: ${group.quantity}`, 105, 38 + index * 7);
    });

    pdf.setFont("helvetica", "bold");
    pdf.text("Records", 200, 28);
    pdf.setFont("helvetica", "normal");
    records.slice(0, 20).forEach((record, index) => {
      const line = `${index + 1}. ${record.defect_type} x ${record.quantity}`;
      pdf.text(line.slice(0, 42), 200, 38 + index * 6);
    });

    pdf.save(`QCFlow-${order.po_number}.pdf`);
  }

  if (!order) {
    return <div className="panel p-5 text-sm text-slate-500">正在生成报告...</div>;
  }

  return (
    <div className="mx-auto max-w-6xl space-y-4">
      <section className="overflow-hidden rounded border border-slate-900 bg-white">
        <div className="grid grid-cols-[1fr_1.6fr] border-b-2 border-slate-900">
          <div className="grid grid-cols-[120px_1fr] border-r-2 border-slate-900 text-sm">
            <div className="border-b border-r border-slate-900 p-2 font-black">检品报告书NO</div>
            <div className="border-b border-slate-900 p-2">{order.po_number}</div>
            <div className="border-b border-r border-slate-900 p-2 font-black">检品依赖者</div>
            <div className="border-b border-slate-900 p-2">{order.customer_name}</div>
            <div className="border-r border-slate-900 p-2 font-black">ブランド名</div>
            <div className="p-2">QCFlow</div>
          </div>
          <div className="p-4 text-center">
            <h1 className="text-2xl font-black tracking-normal">最终检品・检针 报告书</h1>
            <div className="mt-4 grid grid-cols-4 gap-px bg-slate-900 text-sm">
              <div className="bg-white p-2 font-black">工厂名</div>
              <div className="bg-white p-2">{order.factory_name}</div>
              <div className="bg-white p-2 font-black">入荷日</div>
              <div className="bg-white p-2">{order.inbound_date ?? "-"}</div>
              <div className="bg-white p-2 font-black">出荷日</div>
              <div className="bg-white p-2">{order.shipping_date ?? "-"}</div>
              <div className="bg-white p-2 font-black">检品終了日</div>
              <div className="bg-white p-2">{new Date().toLocaleDateString()}</div>
              <div className="bg-white p-2 font-black">番号</div>
              <div className="bg-white p-2">{order.sku}</div>
              <div className="bg-white p-2 font-black">状态</div>
              <div className="bg-white p-2">
                <StatusBadge status={order.status} />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-px bg-slate-900">
          {[
            ["入库总件数", report.total],
            ["缺陷数量", report.defectQty],
            ["不良率", report.rate],
            ["记录数", records.length]
          ].map(([label, value]) => (
            <div key={label} className="bg-white p-4 text-center">
              <p className="text-xs font-black text-slate-500">{label}</p>
              <p className="mt-1 text-2xl font-black tracking-normal">{value}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="panel overflow-hidden">
        <div className="border-b border-line bg-slate-950 px-4 py-3 text-white">
          <h2 className="font-black">问题类别统计</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-[980px] w-full border-collapse text-sm">
            <thead>
              <tr>
                {report.grouped.map((group) => (
                  <th key={group.group} className="border border-slate-300 bg-slate-100 px-3 py-2 text-center font-black">
                    {group.group}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr>
                {report.grouped.map((group) => (
                  <td key={group.group} className="border border-slate-300 align-top">
                    <div className="border-b border-slate-300 bg-amber-50 px-3 py-2 text-center text-lg font-black">{group.quantity}</div>
                    <div className="divide-y divide-slate-200">
                      {group.items.map((item) => (
                        <div key={item.type} className="flex items-center justify-between gap-3 px-3 py-2">
                          <span>{item.type}</span>
                          <span className="font-black text-slate-700">{item.quantity}</span>
                        </div>
                      ))}
                    </div>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-lg font-black">检品记录</h2>
        <div className="grid gap-3 md:grid-cols-2">
          {records.length === 0 && <div className="panel p-4 text-sm text-slate-500">没有缺陷记录。</div>}
          {records.map((record) => (
            <article key={record.id} className="panel flex gap-3 p-3">
              {record.photo_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={record.photo_url} alt={record.defect_type} className="h-20 w-20 shrink-0 rounded object-cover" />
              ) : (
                <div className="grid h-20 w-20 shrink-0 place-items-center rounded bg-slate-100 text-slate-400">
                  <ShieldCheck size={22} />
                </div>
              )}
              <div className="min-w-0">
                <p className="font-black">
                  {record.defect_type} <span className="text-safety">x {record.quantity}</span>
                </p>
                <p className="mt-1 text-xs text-slate-500">{shortDate(record.created_at)}</p>
                {record.remark && <p className="mt-1 line-clamp-2 text-sm text-slate-600">{record.remark}</p>}
              </div>
            </article>
          ))}
        </div>
      </section>

      <div className="sticky bottom-16 grid grid-cols-3 gap-3 rounded border border-line bg-white p-3 shadow-panel md:bottom-4">
        <Link href={`/inspect/${orderId}`} className="secondary-btn">
          检品
        </Link>
        <button type="button" onClick={() => window.print()} className="secondary-btn">
          <Printer size={18} />
          打印
        </button>
        <button type="button" onClick={downloadPdf} className="primary-btn">
          <Download size={18} />
          PDF
        </button>
      </div>
    </div>
  );
}
