"use client";

import { StatusBadge } from "@/components/StatusBadge";
import { supabase } from "@/lib/supabaseClient";
import type { Order, OrderItem } from "@/lib/types";
import { Archive, RotateCcw, Trash2 } from "lucide-react";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type OrderWithItems = Order & {
  items: OrderItem[];
};

function remaining(order: Order) {
  return Math.max(0, Number(order.quantity || 0) - Number(order.inbound_quantity || 0));
}

function groupItemsByColor(items: OrderItem[]) {
  const groups = new Map<string, OrderItem[]>();

  for (const item of items) {
    groups.set(item.color, [...(groups.get(item.color) ?? []), item]);
  }

  return Array.from(groups.entries())
    .map(([color, colorItems]) => ({
      color,
      planned: colorItems.reduce((sum, item) => sum + item.quantity, 0),
      inbound: colorItems.reduce((sum, item) => sum + Number(item.inbound_quantity || 0), 0),
      items: colorItems.sort((a, b) => a.size.localeCompare(b.size, "zh-Hans-CN", { numeric: true }))
    }))
    .sort((a, b) => a.color.localeCompare(b.color, "zh-Hans-CN"));
}

export default function ManageOrdersPage() {
  const [orders, setOrders] = useState<OrderWithItems[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  async function load() {
    setLoading(true);
    const [{ data: orderRows }, { data: itemRows }] = await Promise.all([
      supabase.from("orders").select("*").order("shipping_date", { ascending: true, nullsFirst: false }),
      supabase.from("order_items").select("*")
    ]);

    const items = (itemRows ?? []) as OrderItem[];
    setOrders(
      ((orderRows ?? []) as Order[]).map((order) => ({
        ...order,
        items: items.filter((item) => item.order_id === order.id)
      }))
    );
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const activeOrders = useMemo(() => orders.filter((order) => order.status !== "已完成"), [orders]);
  const shippedOrders = useMemo(() => orders.filter((order) => order.status === "已完成"), [orders]);

  async function updateStatus(orderId: string, status: "未开始" | "已完成") {
    setMessage("");
    const { error } = await supabase.from("orders").update({ status }).eq("id", orderId);

    if (error) {
      setMessage(`${error.message}。请确认 Supabase 已执行最新 schema.sql。`);
      return;
    }

    setOrders((current) => current.map((order) => (order.id === orderId ? { ...order, status } : order)));
  }

  async function deleteOrder(order: OrderWithItems) {
    const ok = window.confirm(`确定删除订单 ${order.po_number} 吗？这个订单的检品记录和附件记录也会一起删除。`);
    if (!ok) return;

    setMessage("");
    const { error } = await supabase.from("orders").delete().eq("id", order.id);

    if (error) {
      setMessage(`${error.message}。请确认 Supabase 已执行最新 schema.sql，并已添加删除权限。`);
      return;
    }

    setOrders((current) => current.filter((item) => item.id !== order.id));
  }

  function renderOrder(order: OrderWithItems) {
    const colorGroups = groupItemsByColor(order.items);

    return (
      <article key={order.id} className="panel p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="truncate text-lg font-black">{order.po_number}</h3>
              <StatusBadge status={order.status} />
            </div>
            <p className="mt-1 text-sm text-slate-500">
              {order.customer_name} / {order.factory_name} / 出货 {order.shipping_date ?? "-"}
            </p>
          </div>
          <div className="shrink-0 text-right">
            <p className="text-xs font-bold text-blue-700">未入库</p>
            <p className="text-xl font-black text-blue-950">{remaining(order)}</p>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          <div className="rounded border border-line bg-blue-50 p-2">
            <p className="text-xs font-bold text-slate-500">预约</p>
            <p className="font-black text-blue-950">{order.quantity}</p>
          </div>
          <div className="rounded border border-line bg-blue-50 p-2">
            <p className="text-xs font-bold text-slate-500">已入</p>
            <p className="font-black text-blue-950">{order.inbound_quantity || 0}</p>
          </div>
          <div className="rounded border border-line bg-blue-50 p-2">
            <p className="text-xs font-bold text-slate-500">颜色</p>
            <p className="font-black text-blue-950">{colorGroups.length}</p>
          </div>
        </div>

        <div className="mt-3 space-y-2">
          {colorGroups.map((group) => (
            <section key={group.color} className="rounded border border-line bg-white p-3">
              <div className="mb-2 flex items-center justify-between gap-2">
                <h4 className="font-black text-blue-950">{group.color}</h4>
                <p className="text-xs font-bold text-blue-700">
                  预约 {group.planned} / 已入 {group.inbound}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
                {group.items.map((item) => (
                  <div key={item.id} className="rounded bg-blue-50 px-2 py-2 text-sm">
                    <p className="font-black">尺码 {item.size}</p>
                    <p className="text-xs text-slate-500">
                      {item.quantity} / 已入 {item.inbound_quantity || 0}
                    </p>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2">
          {order.status === "已完成" ? (
            <button type="button" onClick={() => updateStatus(order.id, "未开始")} className="secondary-btn">
              <RotateCcw size={16} />
              恢复
            </button>
          ) : (
            <button type="button" onClick={() => updateStatus(order.id, "已完成")} className="secondary-btn">
              <Archive size={16} />
              出货
            </button>
          )}
          <Link href={`/inspect/${order.id}`} className="secondary-btn">
            检品
          </Link>
          <button type="button" onClick={() => deleteOrder(order)} className="secondary-btn border-red-200 text-red-700">
            <Trash2 size={16} />
            删除
          </button>
        </div>
      </article>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <div className="mb-2 inline-flex items-center gap-2 rounded bg-blue-100 px-2.5 py-1 text-xs font-black text-blue-900">
          <Archive size={14} />
          总订单
        </div>
        <h1 className="text-2xl font-black tracking-normal text-blue-950">总订单整理</h1>
        <p className="mt-1 text-sm text-blue-700">查看现有订单和已出货订单，订单内部按颜色分类。</p>
      </div>

      {message && <p className="rounded bg-red-50 px-3 py-2 text-sm font-bold text-red-700">{message}</p>}

      {loading && <div className="panel p-5 text-sm text-slate-500">正在加载订单...</div>}

      {!loading && (
        <div className="space-y-5">
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-black text-blue-950">现有订单</h2>
              <span className="rounded bg-blue-100 px-2 py-1 text-xs font-black text-blue-800">{activeOrders.length} 个</span>
            </div>
            {activeOrders.length === 0 && <div className="panel p-4 text-sm text-slate-500">暂无现有订单。</div>}
            {activeOrders.map(renderOrder)}
          </section>

          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-black text-blue-950">已出货订单</h2>
              <span className="rounded bg-blue-100 px-2 py-1 text-xs font-black text-blue-800">{shippedOrders.length} 个</span>
            </div>
            {shippedOrders.length === 0 && <div className="panel p-4 text-sm text-slate-500">暂无已出货订单。</div>}
            {shippedOrders.map(renderOrder)}
          </section>
        </div>
      )}
    </div>
  );
}
