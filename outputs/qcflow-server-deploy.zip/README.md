# QCFlow

鞋服检品管理系统，基于 Next.js App Router、TypeScript、Tailwind CSS 和 Supabase。

## 本地运行

1. 复制环境变量：

```bash
cp .env.example .env.local
```

2. 填入 Supabase 项目的 `NEXT_PUBLIC_SUPABASE_URL` 和 `NEXT_PUBLIC_SUPABASE_ANON_KEY`。

3. 在 Supabase SQL Editor 执行 `supabase/schema.sql`。

4. 安装依赖并启动：

```bash
pnpm install
pnpm dev
```

## Supabase

系统使用：

- Auth：邮箱密码登录
- Database：`orders`、`inspection_records`
- Storage：`inspection-photos` 公共桶

页面：

- `/login` 登录
- `/` Dashboard
- `/orders` 订单列表
- `/orders/new` 创建订单
- `/inspect/[id]` 检品记录
- `/report/[id]` 检品报告
