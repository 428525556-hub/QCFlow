export type OrderStatus = "未开始" | "检品中" | "已完成";

export type InspectionStage = "normal" | "xray";

export type DefectType = string;

export type DefectGroup = {
  group: string;
  items: string[];
};

export type Order = {
  id: string;
  created_at: string;
  user_id: string;
  order_type: "reservation" | "inbound";
  customer_name: string;
  factory_name: string;
  po_number: string;
  sku: string;
  inbound_date: string | null;
  shipping_date: string | null;
  color: string;
  size: string;
  quantity: number;
  inbound_quantity: number;
  status: OrderStatus;
};

export type OrderItem = {
  id: string;
  created_at: string;
  order_id: string;
  user_id: string;
  po_number: string;
  sku: string;
  color: string;
  size: string;
  quantity: number;
  inbound_quantity: number;
};

export type OrderAttachment = {
  id: string;
  created_at: string;
  order_id: string;
  user_id: string;
  file_name: string;
  file_url: string;
  file_path: string;
  mime_type: string | null;
  file_size: number | null;
};

export type InspectionRecord = {
  id: string;
  created_at: string;
  order_id: string;
  user_id: string;
  inspection_stage: InspectionStage;
  defect_type: DefectType;
  quantity: number;
  remark: string | null;
  photo_url: string | null;
  photo_path: string | null;
};

export type Database = {
  public: {
    Tables: {
      orders: {
        Row: Order;
        Insert: Omit<Order, "id" | "created_at"> & { id?: string; created_at?: string };
        Update: Partial<Omit<Order, "id" | "created_at" | "user_id">>;
        Relationships: [];
      };
      order_items: {
        Row: OrderItem;
        Insert: Omit<OrderItem, "id" | "created_at"> & { id?: string; created_at?: string };
        Update: Partial<Omit<OrderItem, "id" | "created_at" | "user_id">>;
        Relationships: [];
      };
      order_attachments: {
        Row: OrderAttachment;
        Insert: Omit<OrderAttachment, "id" | "created_at"> & { id?: string; created_at?: string };
        Update: Partial<Omit<OrderAttachment, "id" | "created_at" | "user_id">>;
        Relationships: [];
      };
      inspection_records: {
        Row: InspectionRecord;
        Insert: Omit<InspectionRecord, "id" | "created_at" | "inspection_stage"> & {
          id?: string;
          created_at?: string;
          inspection_stage?: InspectionStage;
        };
        Update: Partial<Omit<InspectionRecord, "id" | "created_at" | "user_id">>;
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
};

export const normalDefectGroups: DefectGroup[] = [
  {
    group: "危害",
    items: ["异物混入", "异物突起", "钉/针/虫等", "危害其他"]
  },
  {
    group: "帮面和附件",
    items: ["污れ/脏污", "皱/起皱", "伤痕/破损", "左右色差", "色落/色ムラ", "缝制不良/脱线", "形状不良", "饰品不良", "功能性不良", "拉链/扣具不良", "魔术贴/橡筋不良"]
  },
  {
    group: "中底和内里",
    items: ["中底浮起", "内里破损", "商标不良", "中敷污れ", "线头/缝制不良", "中底其他"]
  },
  {
    group: "大底/插跟/贴合",
    items: ["大底皱/伤痕", "接地不稳定", "接着不良/开胶", "底/跟左右高低", "鞋头左右差", "左右尺码差", "底材污れ", "リフト/跟天不良"]
  },
  {
    group: "包装及表示不良",
    items: ["吊牌不良", "外箱不良", "防霉片不良", "定箱不良", "表示错误", "包装破损"]
  },
  {
    group: "常用补充",
    items: ["色差", "尺寸", "左右脚", "脏污", "开胶", "脱线", "备注其他"]
  }
];

export const xrayDefectGroups: DefectGroup[] = [
  {
    group: "检针/X光",
    items: ["检针反应", "X光异物", "ヒール芯不良", "甲底シャンク不良", "钉/金属残留", "断针", "金属粉", "X线其他"]
  },
  ...normalDefectGroups
];

export const defectGroups = normalDefectGroups;
export const defectTypes: DefectType[] = Array.from(new Set(normalDefectGroups.flatMap((group) => group.items)));
export const xrayDefectTypes: DefectType[] = Array.from(new Set(xrayDefectGroups.flatMap((group) => group.items)));
